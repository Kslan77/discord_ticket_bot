const { Client, GatewayIntentBits, Partials, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, PermissionsBitField, AttachmentBuilder } = require('discord.js');
const fs = require('fs');
require('dotenv').config(); 

const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.GuildMembers,
        GatewayIntentBits.MessageContent
    ],
    partials: [Partials.Channel, Partials.Message, Partials.User]
});

// إعدادات السيرفر من .env
const SERVER_ID = process.env.SERVER_ID;
const ADMIN_ROLE_ID = process.env.ADMIN_ROLE_ID;
const HIGH_ADMIN_ROLE_ID = process.env.HIGH_ADMIN_ROLE_ID;
const TICKET_CATEGORY_ID = process.env.TICKET_CATEGORY_ID;
const LOG_CHANNEL_ID = process.env.LOG_CHANNEL_ID;

client.on('ready', () => {
    console.log(`✅ Logged in as ${client.user.tag}`);
});

// إرسال زر فتح التذكرة
client.on('interactionCreate', async interaction => {
    if (!interaction.isCommand()) return;

    if (interaction.commandName === 'setup') { 
        const embed = new EmbedBuilder()
            .setTitle("🎟️ إنشاء تذكرة دعم")
            .setDescription("اضغط على الزر أدناه لفتح تذكرة جديدة.")
            .setColor("Blue");

        const button = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId("open_ticket")
                    .setLabel("📩 فتح تذكرة")
                    .setStyle(ButtonStyle.Primary)
            );

        await interaction.reply({ embeds: [embed], components: [button] });
    }
});

// إنشاء التذكرة وإضافة الأزرار
client.on('interactionCreate', async interaction => {
    if (!interaction.isButton()) return;

    if (interaction.customId === "open_ticket") {
        const guild = client.guilds.cache.get(SERVER_ID);
        const user = interaction.user;

        const channel = await guild.channels.create({
            name: `ticket-${user.username}`,
            type: 0,
            parent: TICKET_CATEGORY_ID,
            permissionOverwrites: [
                { id: guild.id, deny: [PermissionsBitField.Flags.ViewChannel] },
                { id: user.id, allow: [PermissionsBitField.Flags.ViewChannel, PermissionsBitField.Flags.SendMessages] },
                { id: ADMIN_ROLE_ID, allow: [PermissionsBitField.Flags.ViewChannel, PermissionsBitField.Flags.SendMessages] }
            ]
        });

        const buttons = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder().setCustomId("call_owner").setLabel("📢 نداء").setStyle(ButtonStyle.Success),
                new ButtonBuilder().setCustomId("call_high_admin").setLabel("🔔 استدعاء إدارة عليا").setStyle(ButtonStyle.Danger),
                new ButtonBuilder().setCustomId("take_ticket").setLabel("✅ استلام التذكرة").setStyle(ButtonStyle.Secondary),
                new ButtonBuilder().setCustomId("close_ticket").setLabel("❌ إغلاق التذكرة").setStyle(ButtonStyle.Danger)
            );

        const embed = new EmbedBuilder()
            .setTitle("🎫 تذكرة جديدة")
            .setDescription(`تم فتح تذكرة بواسطة ${user}`)
            .setColor("Green");

        await channel.send({ content: `<@${user.id}>`, embeds: [embed], components: [buttons] });
        await interaction.reply({ content: `تم فتح تذكرتك! <#${channel.id}>`, ephemeral: true });
    }

    if (interaction.customId === "call_owner") {
        await interaction.channel.send(`<@${interaction.user.id}> يحتاج إلى المساعدة.`);
        await interaction.reply({ content: "تم إرسال النداء.", ephemeral: true });
    }

    if (interaction.customId === "call_high_admin") {
        await interaction.channel.send(`<@&${HIGH_ADMIN_ROLE_ID}>، هناك طلب يتطلب الإدارة العليا.`);
        await interaction.reply({ content: "تم استدعاء الإدارة العليا.", ephemeral: true });
    }

    if (interaction.customId === "take_ticket") {
        await interaction.reply({ content: `${interaction.user} استلم التذكرة وسيتابع الطلب.`, ephemeral: false });
    }

    if (interaction.customId === "close_ticket") {
        await interaction.reply({ content: "سيتم إغلاق التذكرة خلال 5 ثواني.", ephemeral: true });

        const messages = await interaction.channel.messages.fetch({ limit: 100 });
        const logData = messages.map(m => `[${m.author.tag}] ${m.content}`).reverse().join("\n");

        const logFilePath = `./logs/ticket-${interaction.channel.name}.txt`;
        fs.writeFileSync(logFilePath, logData);

        const logChannel = client.channels.cache.get(LOG_CHANNEL_ID);
        if (logChannel) {
            const logEmbed = new EmbedBuilder()
                .setTitle("📜 تذكرة مغلقة")
                .setDescription(`تم إغلاق التذكرة: <#${interaction.channel.id}>\nبواسطة: ${interaction.user}`)
                .setColor("Red");

            await logChannel.send({ embeds: [logEmbed], files: [new AttachmentBuilder(logFilePath)] });
        }

        setTimeout(async () => {
            await interaction.channel.delete();
            fs.unlinkSync(logFilePath);
        }, 5000);
    }
});

client.login(process.env.TOKEN);
